import { Component } from '@angular/core';

@Component({
    selector: 'flow-cmp',
    moduleId: module.id,
    templateUrl: 'flow.component.html'
})

export class FlowComponent{}
