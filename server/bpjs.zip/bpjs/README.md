1. mvn package
2. java -jar target\BPWorkBench-0.5-DEV.jar
