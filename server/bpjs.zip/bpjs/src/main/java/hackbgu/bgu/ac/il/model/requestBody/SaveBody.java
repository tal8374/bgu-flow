package hackbgu.bgu.ac.il.model.requestBody;

public class SaveBody {

    public String graph;

}
