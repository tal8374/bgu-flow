package hackbgu.bgu.ac.il.model.requestBody;

import java.util.Map;

public class InsertEventBody {

    public String eventName;
    public Map<String, String> data;

}
